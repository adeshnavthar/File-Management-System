import os
from blood_p import Blood1
from datetime import date
from datetime import datetime

class Patient:
    def add(self,id):
        with open("patient_details.txt","a") as userfile:
                userfile.write(str(id))
                userfile.write("-")
                print("Patient added...")

    def add_p(self,b1):
        with open("patient_details.txt","a") as userfile:
            userfile.write(str(b1))
            userfile.write("\n")
            print("Patient added successfully... ")
            print("===========================================================================================================")

        # to update blood quantity in txt files
        with open("patient_details.txt","r") as fp:
            for i in fp:
                list=[]
                list_p = i.split("-")

                # A+
                if list_p[3]=="A_positive":
                    d = list_p[4]
                    with open("A+ details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("A+ details.txt","w") as fp:
                        fp.write(str(r))

                # A-
                elif list_p[3]=="A_negative":
                    d = list_p[4]
                    with open("A- details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("A- details.txt","w") as fp:
                        fp.write(str(r))

                # B+
                elif list_p[3]=="B_positive":
                    d = list_p[4]
                    with open("B+ details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("B+ details.txt","w") as fp:
                        fp.write(str(r))

                # B-
                elif list_p[3]=="AB_positive":
                    d = list_p[4]
                    with open("AB+ details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("AB+ details.txt","w") as fp:
                        fp.write(str(r))

                # AB+
                elif list_p[3]=="AB_positive":
                    d = list_p[4]
                    with open("AB+ details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("AB+ details.txt","w") as fp:
                        fp.write(str(r))

                # AB-
                elif list_p[3]=="AB_negative":
                    d = list_p[4]
                    with open("AB- details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("AB- details.txt","w") as fp:
                        fp.write(str(r))

                # O+
                elif list_p[3]=="O_positive":
                    d = list_p[4]
                    with open("O+ details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("O+ details.txt","w") as fp:
                        fp.write(str(r))

                # O-
                elif list_p[3]=="O_negative":
                    d = list_p[4]
                    with open("O- details.txt","r") as file:
                        t = file.read()
                        r = int(t) - int(d)
                    with open("O- details.txt","w") as fp:
                        fp.write(str(r))

                else:
                    list.append(i)
#========================================================================================================================                           
    def display(self):
        try:
            total_p =0
            if(os.path.exists("patient_details.txt")):
                with open("patient_details.txt","r") as patientfile:
                        for i in patientfile:
                            user_split=i.split("-")
                            #DOB_split=user_split[6].split()
                            # DOB_split=user_split[9].split()
                            print("ID:",user_split[0],"Name:",user_split[1],"Gender:",user_split[2],"Blood Group:",user_split[3],"Quantity of blood req.:",\
                                  user_split[4],"Date of purchase:",user_split[7],"/",user_split[6],"/",user_split[5],"Mobile No.:",user_split[8],\
                                        "Email:",user_split[9],"Address:",user_split[10],"Pincode:",user_split[11])
                            total_p += 1
                            #print("=============================================================================================================================================================")
        except IndexError:
            print("Error...",user_split[0] ," User not registered yet...")
            print("=============================================================================================================================================================")
        except:
            print("Unexpected error")
            print("=============================================================================================================================================================")
        else:
             print("Total No. of Patients: ",total_p)

             
    def search(self,p_id):
            if (os.path.exists("patient_details.txt")):
                with open("patient_details.txt","r") as patientfile:
                        try:
                            for i in patientfile:
                                user_split=i.split("-")
                                #DOB_split=user_split[6].split()
                                if p_id==str(user_split[0]):
                                    print("Patient found-")
                                    print("------------- ")
                                    print("ID:",user_split[0],"\nName:",user_split[1],"\nGender:",user_split[2],"\nBlood Group:",user_split[3],"\nQuantity of blood purchased.:",\
                                  user_split[4]," ml","\nDate of purchase:",user_split[7],"/",user_split[6],"/",user_split[5],"\nMobile No.:",user_split[8],\
                                        "\nEmail:",user_split[9],"\nAddress:",user_split[10],user_split[11])
                                    print("=============================================================================================================================================")
                                    break
                            else:
                                print("Patient not found...")
                                print("=============================================================================================================================================")
                                

                        except IndexError:
                            print("Patient not registered yet  OR Enter valid ID...")
                            print("=============================================================================================================================================================")
                        #finally:
                            #print("======================================================================================")

    def update(self,p_id):
        list2 = []
        if (os.path.exists("patient_details.txt")):
            with open("patient_details.txt","r") as patientfile:
                for i in patientfile:
                    user_split=i.split("-")
                    if len(user_split)<3:
                        if p_id == user_split[0]:
                            print("Patient details not added yet.Please add details first... ")
                            p = Patient()
                            id = user_split[0]
                            p.add_pid(id)
                            break
                        else:
                            list2.append(i)
                    else:
                        if p_id == user_split[0]:
                            print("Existing details:")
                            print(i)
                            print()
                            print("Enter new details of patient: ")
                            name = input("Enter patient/blood reciever name(new): ")
                            #print("Enter new date of birth below")
                            # day = int(input("Enter date (dd): "))
                            # month = int(input("Enter month (mm): "))
                            # year = int(input("Enter year (yyyy): "))
                            # DOB = datetime.date(year,month,day)
                            gender = input("Gender: ")
                            print()
                            btype = 0
                            print("""1) A+      2) A-      3) B+    4) B-
    5) AB+     6) AB-     7) O+    8) O-
    Select your Blood Group carefully :""")
                            blood_g = int(input("Your required Blood Group option: "))
                            if blood_g ==1:
                                btype = "A_positive"

                            elif blood_g ==2:
                                btype = "A_negative"
                                
                            elif blood_g ==3:
                                btype ="B_positive"
                                
                            elif blood_g ==4:
                                btype ="B_negative"
                                
                            elif blood_g ==5:
                                btype ="AB_positive"
                                
                            elif blood_g ==6:
                                btype ="AB_negative"
                                
                            elif blood_g ==7:
                                btype ="O_positive"
                                
                            elif blood_g ==8:
                                btype ="O_negative"
                                

                            quantity = int(input("Quantity of Blood required (ml): "))
                            print("Enter blood purchased date: ")
                            dd = int(input("Enter date (dd): "))
                            mm = int(input("Enter month (mm): "))
                            yy = int(input("Enter year (yyyy): "))
                            dop = datetime.date(yy,mm,dd)
                            mobile = int(input("Mobile: "))
                            email = input("Email: ")
                            address = input("Address: ")
                            pin = int(input("Pincode: "))
                            print("\n")

                            p = Blood1(name,gender,quantity,btype,dop,mobile,email,address,pin)
                            list2.append(p_id + "-" +str(p)+"\n")
                        
                        else:
                            list2.append(i)
                    
                with open("patient_details.txt","w") as file:
                    for i in list2:    
                        file.write(str(i))
                print(p_id," Patient details updated...")