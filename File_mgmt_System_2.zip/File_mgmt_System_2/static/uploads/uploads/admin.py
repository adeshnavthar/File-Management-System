print("Enter correct username and password combo to continue") 
count = 0
while count < 3:
 

    username = input("Enter username:")
    password = input("Enter password:")
    if password =='cake1001%' and username=='harshu_s_bakeway':
        print("welcome to Harshu's Bakeway")
        break
    else:
        print(" sorry, enter the correct password ")

if(__name__=="__main__"):
  
  a = CakeMgmt()
  ch=0
while(ch!=10 ):
    print('''
            1.Display
            2.add  new cake variety
            3. change the price of cake
            4.Remove cake variety '''
            
            
              )
    
    ch = int(input("Enter the choice:"))
    if(ch==1):
     a.Display(id)






    if(ch==2):
        id = int(input("Enter the cake Id:"))
        nm = input("Enter cake name:")
        price= int(input("Enter cake price:"))
        quantity= int(input("Enter quantity:"))
        c=Cake(id,nm,price,quantity) 
       # a = CakeMgmt()
        a.addCake(c)

    elif (ch ==3):
        a.change_price(id)
        id = int(input("Enter the cake Id:"))
        name = input("Enter cake name:") 
        price=int(input("Enter the new price of cake:"))  
        quantity = int(input("Enter the quantity of cake:"))
    elif (ch==4):
        id = int(input("Enter id to remove cake:"))
        a.remove_cake(id)