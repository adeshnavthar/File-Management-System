from cake import Cake
from usermgmt import UserMgmt
print("Enter correct username and password combo to continue") 
count = 0
while count < 3:
# password= cake1001%
# username= harshu_s_bakeway 

    username = input("Enter username:")
    password = input("Enter password:")
    if password =='123' and username=='har':
        print("welcome to Harshu's Bakeway")
        break
    else:
        print(" sorry, enter the correct password ")
if(__name__=="__main__"):
     u= UserMgmt()
     ch=0
while(ch!=10 ):
    print('''
            1.Display
            6.search cake by id
            7.  addToCart
            8. purchase
           '''
             )
    
    ch = int(input("Enter the choice:"))

    if(ch==1):
      u.Display(id)

    elif(ch ==6):
            id = int(input("Enter id to search: "))
            u.search(id)
    
    elif(ch==7):
             id=int(input("Enter id to add to cart:"))
             u.addToCart(id)
    
    elif(ch==8):
           id=int(input("Enter id to purchase:"))
           u.purchase(id)
   