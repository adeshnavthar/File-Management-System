from django.shortcuts import render,redirect
from django.contrib.auth import logout
from django.http import HttpResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from .models import Post
from .models import UserInfo
from datetime import datetime,date
import os

# Create your views here

def home(request):
    username = request.session.get('username')
    files = Post.objects.filter(username=username)
    print(files)
    return render(request, "Staff/Home.html", {"files": files,'username':username})
    


def Login(request):
    if request.method == "GET":
        return render(request, "Staff/Login.html")
    else:
        username = request.POST.get("username")
        password = request.POST.get("password")
        
        try:
            user = UserInfo.objects.get(username=username, password=password)
        except UserInfo.DoesNotExist:
            return redirect("/")
        else:
            request.session['username'] = username
            files = Post.objects.filter(username=username)
            print(files) 
            
            return render(request, "Staff/Home.html", {"files": files})

def register(request):
    if request.method == "GET":
        return render(request,"Staff/Register.html")
    else:
        username = request.POST["username"]
        password = request.POST["password"]
        email = request.POST["email"]
        try:
            user = UserInfo.objects.get(username=username)
        except:
    
            user = UserInfo(username,password,email)
            user.save()
            return redirect("/")
        else:
            return render(request,"Staff/Register.html",{"error":"User already present"})
        

def logout_view(request):
    logout(request)
    return redirect(Login)

def file_management_view(request):
  
    files = Post.objects.all()  

    context = {
        'username': request.user.username,
        'files': files,                                                                         
    }
    return render(request, 'Home.html', context)


from datetime import date
from django.shortcuts import render, redirect
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from .models import Post
import os

def upload_file(request):
    if request.method == 'POST' and request.FILES.getlist('files'):
        uploaded_files = request.FILES.getlist('files')
        username = request.session.get('username')
        date_created = date.today()
        
        for uploaded_file in uploaded_files:
            fs = FileSystemStorage(location=os.path.join(settings.MEDIA_ROOT, 'uploads'))
            fs.save(uploaded_file.name, uploaded_file)

            post = Post(file_name=uploaded_file.name, username=username, date_created=date_created)
            post.save()

        return render(request, 'Staff/upload_success.html') 
    else:
        return render(request, 'Staff/Upload_file.html')
