from django.urls import path
from . import views

urlpatterns = [    
    path('',views.Login),
    path('upload/home',views.home),

    path('register',views.register),
    path('Login',views.Login),
    path('logout', views.logout_view),
    path('upload/', views.upload_file),
]
