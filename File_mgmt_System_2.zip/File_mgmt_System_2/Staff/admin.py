from django.contrib import admin
from .models import Post,UserInfo

# staff/admin.py

admin.site.register(Post)


